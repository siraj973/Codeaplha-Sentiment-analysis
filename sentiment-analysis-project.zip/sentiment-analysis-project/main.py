from pathlib import Path
import argparse, re
import pandas as pd
import matplotlib.pyplot as plt
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"

def clean_text(value):
    if pd.isna(value):
        return ""
    text = str(value)
    text = re.sub(r"https?://\\S+|www\\.\\S+", " ", text)
    text = re.sub(r"@\\w+", " ", text)
    return re.sub(r"\\s+", " ", text).strip()

def find_text_column(df):
    preferred = ["review", "text", "comment", "content", "tweet", "feedback"]
    lookup = {str(c).strip().lower(): c for c in df.columns}
    for name in preferred:
        if name in lookup:
            return lookup[name]
    cols = df.select_dtypes(include=["object", "string"]).columns.tolist()
    if cols:
        return cols[0]
    raise ValueError("No text column found. Add a 'review' column or pass --text-column.")

def classify(score):
    if score >= 0.05:
        return "Positive"
    if score <= -0.05:
        return "Negative"
    return "Neutral"

def main():
    parser = argparse.ArgumentParser(description="Sentiment analysis using VADER NLP")
    parser.add_argument("--data", default=str(ROOT / "reviews.csv"), help="Path to input CSV")
    parser.add_argument("--text-column", default=None, help="Text column name")
    args = parser.parse_args()
    path = Path(args.data)
    if not path.exists():
        raise FileNotFoundError(f"CSV not found: {path}")
    df = pd.read_csv(path)
    if df.empty:
        raise ValueError("CSV contains no rows.")
    col = args.text_column or find_text_column(df)
    if col not in df.columns:
        raise ValueError(f"Column '{col}' not found. Available columns: {list(df.columns)}")

    analyzer = SentimentIntensityAnalyzer()
    df["cleaned_text"] = df[col].apply(clean_text)
    df["sentiment_score"] = df["cleaned_text"].apply(
        lambda text: analyzer.polarity_scores(text)["compound"] if text else 0.0
    )
    df["sentiment"] = df["sentiment_score"].apply(classify)
    OUT.mkdir(exist_ok=True)
    df.to_csv(OUT / "sentiment_results.csv", index=False)

    counts = df["sentiment"].value_counts().reindex(["Positive", "Neutral", "Negative"], fill_value=0)
    summary = pd.DataFrame({
        "sentiment": counts.index,
        "count": counts.values,
        "percentage": (counts.values / len(df) * 100).round(2)
    })
    summary.to_csv(OUT / "sentiment_summary.csv", index=False)

    plt.figure(figsize=(8, 5))
    counts.plot(kind="bar", edgecolor="black")
    plt.title("Sentiment Distribution")
    plt.xlabel("Sentiment")
    plt.ylabel("Number of reviews")
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(OUT / "sentiment_distribution.png", dpi=160)
    plt.close()

    plt.figure(figsize=(8, 5))
    plt.hist(df["sentiment_score"], bins=10, edgecolor="black")
    plt.title("Distribution of Sentiment Scores")
    plt.xlabel("VADER compound score (-1 to +1)")
    plt.ylabel("Number of reviews")
    plt.tight_layout()
    plt.savefig(OUT / "sentiment_scores.png", dpi=160)
    plt.close()

    report = [
        "SENTIMENT ANALYSIS REPORT", "=" * 26,
        f"Input file: {path.name}", f"Text column: {col}",
        f"Total records: {len(df)}",
        f"Empty text records: {(df['cleaned_text'].str.len() == 0).sum()}",
        "", "SENTIMENT SUMMARY", summary.to_string(index=False),
        "", "Method: VADER lexicon-based sentiment analysis",
        "Positive: score >= 0.05; Negative: score <= -0.05; otherwise Neutral.",
        "Limitations: sarcasm, slang, mixed-language text, and context can affect accuracy."
    ]
    (OUT / "sentiment_report.txt").write_text("\n".join(report), encoding="utf-8")
    print("Sentiment analysis complete.")
    print(summary.to_string(index=False))
    print("Results saved in the outputs/ folder.")

if __name__ == "__main__":
    main()
