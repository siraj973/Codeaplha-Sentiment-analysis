# Sentiment Analysis using Python and NLP

A beginner-friendly project for classifying text reviews as **Positive**, **Neutral**, or **Negative** using VADER, a lexicon-based NLP sentiment analyzer.

## Features
- Reads reviews from CSV
- Cleans URLs, usernames, and extra whitespace
- Calculates compound sentiment scores
- Classifies each review
- Exports analyzed reviews and summary CSVs
- Creates charts and a text report

## Setup and run
Python 3.10+ is recommended.

```bash
python -m pip install -r requirements.txt
python main.py
```

If `python` does not work on Windows, try `py` instead.

## Use your own dataset
Use a CSV with a text column called `review`, `text`, `comment`, `content`, `tweet`, or `feedback`:

```bash
python main.py --data "path/to/reviews.csv"
```

To specify the column name:

```bash
python main.py --data "path/to/reviews.csv" --text-column "customer_review"
```

## Sentiment thresholds
- Positive: VADER compound score >= 0.05
- Negative: VADER compound score <= -0.05
- Neutral: score between -0.05 and 0.05

## Outputs
- `outputs/sentiment_results.csv`
- `outputs/sentiment_summary.csv`
- `outputs/sentiment_distribution.png`
- `outputs/sentiment_scores.png`
- `outputs/sentiment_report.txt`

## Limitations
VADER works best for English text and can misread sarcasm, slang, mixed-language text, and context. Results are estimates, not guaranteed interpretations. Do not publish private customer information in a public repository.

## GitHub
Create a repository named `sentiment-analysis-python`, then upload `main.py`, `reviews.csv`, `requirements.txt`, and `README.md`.
